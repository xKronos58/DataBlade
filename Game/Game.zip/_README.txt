Add a folder @"C:\\Users\\Public\\DatabladeSaves\\" so that the program can write saves, 
i do need to migrate this to the temp fold or some other folder, but havent gotten around to it